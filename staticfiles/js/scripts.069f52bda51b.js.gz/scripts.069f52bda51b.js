// $('.dropdown-toggle').dropdown()

// $('.berita').click(function (event) {
//   $(event.target).css("color", "red");
// });

